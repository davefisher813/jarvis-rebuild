import type { Store, ItemData } from "@core";
import type { EventInput } from "../../events";
import {
  ENTITY_STRAND, STRAND_CAP_TOTAL, STRAND_CAP_PER_CATEGORY, EVIDENCE_CAP, NO_PATTERN_TWIN,
  type Strand, type StrandData, type StrandCategory, type StrandEvidence, type StrandStrength, type DerivationKey,
} from "./types";

// The strand store (Brain Layer 2). Every mutation that says something about
// a derivation's accuracy also emits an event, because the nod test is
// operational here, not a slogan: correction and deletion rates PER DERIVATION
// are what decide whether a derivation keeps speaking (see moments.ts).
//
// Emission map:
//   accept (create watched)  -> strand.created   kind = derivation
//   edit a watched strand    -> strand.corrected kind = derivation (the text
//                               was not right as written; that is a correction
//                               even though the fact survives, and the edit
//                               promotes source to told, which is earned)
//   delete a watched strand  -> strand.deleted   kind = derivation
// Typed strands (told) emit created without a kind; their edits are not
// corrections of any derivation.

// What happened when a moment was accepted. Three outcomes, because the
// caller has to say something true about each and "null" could only ever
// carry one message for two very different situations.
export type AcceptResult =
  // new strand, JARVIS learned it. `replaced` when it took the place of the
  // opposite answer to the same question (see the twin retirement below), so
  // the caller can say that out loud instead of quietly losing a fact.
  | { outcome: "created"; id: string; replaced?: true }
  | { outcome: "refreshed"; id: string }  // already knew; receipts brought up to date
  | { outcome: "full"; id?: undefined };  // genome or category at its cap

export class StrandsService {
  constructor(private store: Store, private ownerId: string, private emit?: (e: EventInput) => void) {}

  async list(): Promise<Strand[]> {
    const items = await this.store.listForUser(this.ownerId, ENTITY_STRAND);
    return items
      .map((i) => ({ id: i.id, data: i.data as unknown as StrandData }))
      .sort((a, b) => b.data.createdAt.localeCompare(a.data.createdAt));
  }

  async active(): Promise<Strand[]> {
    return (await this.list()).filter((s) => s.data.status === "active");
  }

  // A being-known moment was accepted: the fact becomes a watched strand with
  // its receipts. Caps enforced here; a full genome refuses quietly (null)
  // rather than growing into the fifty-maybes failure mode.
  //
  // RE-DERIVATION REFRESHES (2026-08-24). byDerivation and refreshEvidence
  // were written for exactly this and never called: this method simply
  // returned null when the derivation already existed, which had two costs.
  // The fresher receipts were thrown on the floor, so a strand's evidence was
  // frozen at whatever the first accept happened to see. And the only caller
  // reads null as "the Brain is full" and said so in a toast, which was a lie
  // every time the real reason was "you already have this one".
  //
  // So the refusals are now distinguishable, and the caller can say something
  // true about each.
  async accept(
    text: string,
    category: StrandCategory,
    derivation: DerivationKey,
    evidence: StrandEvidence[],
    today: string,
  ): Promise<AcceptResult> {
    const all = await this.list();
    const existing = all.find((s) => s.data.derivation === derivation);
    if (existing) {
      // Quietly, and without touching the TEXT: if he edited the sentence it
      // is told-rank now, and a later re-derivation must not overwrite his
      // words with the machine's.
      await this.refreshEvidence(existing, evidence, today);
      return { outcome: "refreshed", id: existing.id };
    }
    // THE EVIDENCE FLIPPED (2026-09-07). A no-pattern fact and the fact it
    // denies are two answers to one question (NO_PATTERN_TWIN in types.ts),
    // so accepting one has to retire the other: a genome holding both
    // "gets things done between 9 PM and midnight" AND "finishes things
    // across the whole day" would ride every prompt as a contradiction.
    //
    // The twin is excluded from the caps below, because its slot is the slot
    // being taken, and it is deleted AFTER the create, so a create that
    // throws leaves the old fact standing rather than losing both.
    //
    // Deleted WITHOUT a strand.deleted event, which is the one thing to get
    // right here. That event feeds the nod test (moments.ts), which reads a
    // deletion as "this derivation was wrong about him". The twin was not
    // wrong; his life changed. Emitting would mute a correct detector after
    // two honest flips.
    const twinKey = NO_PATTERN_TWIN[derivation];
    const twin = twinKey ? all.find((s) => s.data.derivation === twinKey) ?? null : null;
    const others = twin ? all.filter((s) => s.id !== twin.id) : all;
    if (others.length >= STRAND_CAP_TOTAL) return { outcome: "full" };
    if (others.filter((s) => s.data.category === category).length >= STRAND_CAP_PER_CATEGORY) return { outcome: "full" };
    const data: StrandData = {
      text: text.trim(),
      category,
      source: "watched",
      strength: "influence",
      status: "active",
      createdAt: today,
      lastConfirmed: today,
      derivation,
      evidence: evidence.slice(0, EVIDENCE_CAP),
    };
    const id = await this.store.create(this.ownerId, ENTITY_STRAND, data as unknown as ItemData);
    this.emit?.({ type: "strand.created", entityType: ENTITY_STRAND, entityId: id, props: { kind: derivation, category } });
    if (twin) {
      await this.store.delete(this.ownerId, twin.id);
      return { outcome: "created", id, replaced: true };
    }
    return { outcome: "created", id };
  }

  // The user typed one sentence themselves: source told, the highest rank,
  // because it was deliberate. strength stays influence unless they made it
  // a rule on purpose.
  async add(text: string, category: StrandCategory, today: string, strength: "influence" | "rule" = "influence"): Promise<string | null> {
    const t = text.trim();
    if (!t) return null;
    const all = await this.list();
    if (all.length >= STRAND_CAP_TOTAL) return null;
    if (all.filter((s) => s.data.category === category).length >= STRAND_CAP_PER_CATEGORY) return null;
    const data: StrandData = {
      text: t, category, source: "told", strength, status: "active",
      createdAt: today, lastConfirmed: today,
    };
    const id = await this.store.create(this.ownerId, ENTITY_STRAND, data as unknown as ItemData);
    this.emit?.({ type: "strand.created", entityType: ENTITY_STRAND, entityId: id, props: { category } });
    return id;
  }

  // ONBOARDING SEEDS (handoff item 4, decision x4, Dave's option A on
  // 2026-09-04). Separate from add() on purpose, and the difference is one
  // word: SOURCE.
  //
  // add() writes "told", the top rank, because told is EARNED: the user typed
  // the sentence, or corrected one JARVIS wrote. A chip tapped during intake
  // is neither. It is a half-attention self-report made before the app has
  // watched the person do anything, which is exactly what "asked" is for, and
  // "asked" sits BELOW "watched" so a month of real behaviour can quietly
  // overrule a guess made on day one without anyone having to un-teach it.
  //
  // Same caps as everything else: a seeded genome that fills the per-category
  // ceiling would lock real derivations out of that category later.
  async seed(text: string, category: StrandCategory, today: string): Promise<string | null> {
    const t = text.trim();
    if (!t) return null;
    const all = await this.list();
    if (all.length >= STRAND_CAP_TOTAL) return null;
    if (all.filter((s) => s.data.category === category).length >= STRAND_CAP_PER_CATEGORY) return null;
    const data: StrandData = {
      text: t, category, source: "asked", strength: "influence", status: "active",
      createdAt: today, lastConfirmed: today,
    };
    const id = await this.store.create(this.ownerId, ENTITY_STRAND, data as unknown as ItemData);
    this.emit?.({ type: "strand.created", entityType: ENTITY_STRAND, entityId: id, props: { category } });
    return id;
  }

  // Editing the words of a watched strand is a correction of its derivation
  // (the sentence was not one the user would nod at as written), and the
  // corrected text is EARNED told-rank from then on.
  async edit(s: Strand, text: string, today: string): Promise<void> {
    const t = text.trim();
    if (!t || t === s.data.text) return;
    if (s.data.derivation) {
      this.emit?.({ type: "strand.corrected", entityType: ENTITY_STRAND, entityId: s.id, props: { kind: s.data.derivation } });
    }
    await this.store.update(this.ownerId, s.id, { text: t, source: "told", lastConfirmed: today } as unknown as ItemData);
  }

  async setStatus(s: Strand, status: "active" | "paused"): Promise<void> {
    await this.store.update(this.ownerId, s.id, { status } as unknown as ItemData);
  }

  // S4-Q24 (2026-09-04): "nothing in the app ever promotes an influence to
  // a rule" (types.ts's own doctrine) describes what must never happen
  // AUTOMATICALLY. It does not forbid the person themselves saying so on
  // purpose, which is the one thing this method is for -- there is no other
  // caller anywhere, and none is meant to exist. Deliberately untouched:
  // source and derivation. A watched strand made into a rule is still
  // watched; the user is stating a constraint about the fact, not claiming
  // authorship of the sentence.
  async setStrength(s: Strand, strength: StrandStrength): Promise<void> {
    await this.store.update(this.ownerId, s.id, { strength } as unknown as ItemData);
  }

  // Move a strand to a different bucket, in place. Refuses (false) when the
  // TARGET category is already at its per-category cap, the same ceiling
  // every other write here respects -- so moving a fact out of a wrong
  // bucket can never quietly evict one already sitting in the right one, or
  // breach the cap by relocation instead of creation. The strand itself is
  // excluded from its own target count, since re-picking the bucket it is
  // already in is a same-category no-op the caller filters out before this
  // is ever reached.
  async recategorize(s: Strand, category: StrandCategory): Promise<boolean> {
    if (category === s.data.category) return true;
    const all = await this.list();
    if (all.filter((x) => x.data.category === category && x.id !== s.id).length >= STRAND_CAP_PER_CATEGORY) return false;
    await this.store.update(this.ownerId, s.id, { category } as unknown as ItemData);
    return true;
  }

  async confirm(s: Strand, today: string): Promise<void> {
    await this.store.update(this.ownerId, s.id, { lastConfirmed: today } as unknown as ItemData);
  }

  // Refresh a watched strand's receipts on re-derivation, quietly.
  async refreshEvidence(s: Strand, evidence: StrandEvidence[], today: string): Promise<void> {
    await this.store.update(this.ownerId, s.id, { evidence: evidence.slice(0, EVIDENCE_CAP), lastConfirmed: today } as unknown as ItemData);
  }

  async remove(s: Strand): Promise<void> {
    if (s.data.derivation) {
      this.emit?.({ type: "strand.deleted", entityType: ENTITY_STRAND, entityId: s.id, props: { kind: s.data.derivation } });
    }
    await this.store.delete(this.ownerId, s.id);
  }
}
