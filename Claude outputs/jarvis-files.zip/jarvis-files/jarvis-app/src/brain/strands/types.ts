// Strands: Brain Layer 2 (queue item 04, design in claude/BRAIN_REBUILD_DESIGN.md).
// A strand is one plain-language fact about the user, one line, categorized,
// visible, editable. The genome, not the log: low-volume, so it rides the
// item table (registry migration 0027).
//
// Doctrine carried in the shape:
// - source ranks: told outranks everything, and told is EARNED (typed or
//   corrected in the app). watched carries evidence receipts. asked is a
//   half-attention self-report that watched data may later challenge.
// - strength: influence biases, rule binds. Rules are ONLY user-stated;
//   nothing in the app ever promotes an influence to a rule.
// - evidence is typed numbers and days, never free text, matching the event
//   log's own payload law: receipts render from numbers at display time.

export const ENTITY_STRAND = "strand";

export type StrandCategory = "energy" | "work_style" | "writing" | "people" | "values" | "routine";
export type StrandSource = "watched" | "asked" | "told" | "uploaded";
export type StrandStrength = "influence" | "rule";
export type StrandStatus = "active" | "paused";

// The launch derivations: the only facts the log honestly supports.
//
// The first four were the launch set (design doc, locked). The next two are
// the Brain build handoff's item 3, "one new detector per newly-instrumented
// module", and they land under exactly the gates the original four use:
//
//   training_window  reads workout rows that have been in the durable log
//                    since the gym shipped. Nothing new was instrumented for
//                    it. Every derivation filtered them out (taskDone drops
//                    kind "workout", correctly, because a session is not a
//                    task) and then nothing else read them, so a month of
//                    real training taught the Brain nothing. It does now.
//   email_window     reads email.handled, the semantic act added for it.
//
// Both are the same three-hour band shape completion_window proved, sharing
// completionBand() so there is one definition of "when does this happen" and
// four readers of it.
//   people_rhythm    reads email.handled rows carrying a PERSON (UP-MIND-10
//                    put the id on them), so a contact the user deals with
//                    constantly stops reading NO LABEL YET on their card.
//   gone_quiet       someone the user labelled, who has gone quiet. Reads
//                    the cached last-contact lookup the person card already
//                    runs, not the event log: a person who has gone quiet
//                    has no rows in a 30-day window by definition.
//
// NO PATTERN IS A FACT (Dave, 2026-09-07). Two of these detectors can now
// answer their question in the other direction, and the absence gets its own
// key:
//
//   completion_no_band  158 completions and no 3-hour stretch holding 40
//                       percent of them. Every AI prompt used to get nothing
//                       here, so the model was free to assume there is a best
//                       time to put hard work. There is not, and saying so
//                       stops the guess.
//   slip_no_leader      66 pushes and no area in front. "Which area slips" is
//                       a question the model will otherwise answer by picking
//                       one, so this stops a false attribution rather than
//                       adding one.
//
// Only these two. training_window and email_window have the same band shape
// and the absence of a band there changes nothing any consumer does; plan_rate
// already speaks in both directions. A no-pattern fact earns its key by
// changing what JARVIS does, not by describing the user back at himself.
export type DerivationKey =
  | "completion_window" | "slip_category" | "plan_rate" | "task_timing"
  | "training_window" | "email_window"
  | "people_rhythm" | "gone_quiet"
  | "completion_no_band" | "slip_no_leader";

// THE TWO ANSWERS TO ONE QUESTION, and why they are two keys rather than one.
//
// Sharing a key with the positive twin would make the pair impossible to
// contradict: accepting either would suppress the other forever
// (moments.ts filters on the derivation a strand already holds). That reads
// as safe and is not. A shared key also shares the nod test, so deleting
// "finishes across the whole day" twice would mute the BAND detector, and a
// correction of one sentence would be counted against a different one. The
// nod test measures whether a sentence is right; these are different
// sentences making opposite claims, so they need separate records.
//
// The cost of separate keys is the contradiction: both facts sitting in the
// genome at once, riding every prompt. That is closed here rather than left
// to luck. deriveAll can only ever emit ONE half of a pair (each detector
// returns null when its twin speaks), so the two can never be OFFERED
// together; and StrandsService.accept retires the twin's strand when the
// other half is accepted, so they can never be HELD together either. The
// window in which a genome holds both is zero wide.
//
// Read by: StrandsService (the retirement), brain/readiness.ts (one panel row
// per question, not two), and the law that pins both.
export const NO_PATTERN_TWIN: Partial<Record<DerivationKey, DerivationKey>> = {
  completion_window: "completion_no_band",
  completion_no_band: "completion_window",
  slip_category: "slip_no_leader",
  slip_no_leader: "slip_category",
};

// One receipt. Meaning of a/b depends on the derivation and is decided by the
// renderer: completion_window a=hour; slip_category a=count;
// plan_rate a=done b=picked; task_timing a=planned b=committed minutes.
export interface StrandEvidence { day: string; a?: number; b?: number }

export interface StrandData {
  text: string;
  category: StrandCategory;
  source: StrandSource;
  strength: StrandStrength;
  status: StrandStatus;
  createdAt: string; // ISO date
  // ISO date. Written on accept, on a re-derivation, on an edit, and by
  // confirm(); READ by the Brain page, which shows "Confirmed 12 Aug".
  //
  // The comment here used to say "strands expire, confirmation refreshes".
  // Nothing expires. No code anywhere reads this date and acts on it, and a
  // strand from March is exactly as loud today as one confirmed this morning.
  // Corrected rather than implemented (2026-08-24) because an expiry policy
  // is a decision about JARVIS quietly forgetting things it was told, and how
  // long is long enough is Dave's call, not a number to invent in a type.
  lastConfirmed: string;
  derivation?: DerivationKey; // watched strands only: which derivation said it
  evidence?: StrandEvidence[]; // watched strands only, capped
}

export interface Strand {
  id: string;
  data: StrandData;
}

export const STRAND_CATEGORY_LABEL: Record<StrandCategory, string> = {
  energy: "Energy",
  work_style: "Work Style",
  writing: "Writing",
  people: "People",
  values: "Values",
  routine: "Routine",
};

// Genome constraints (design doc): the whole point is ten certain facts over
// fifty maybes. Caps enforced at creation time by the service.
export const STRAND_CAP_TOTAL = 50;
export const STRAND_CAP_PER_CATEGORY = 12;
export const EVIDENCE_CAP = 6;
