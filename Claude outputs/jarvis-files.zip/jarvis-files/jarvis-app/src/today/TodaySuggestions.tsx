import { useCallback, useEffect, useState, type ReactNode } from "react";
import type { AIService } from "../ai/AIService";
import { useAIContext, todayISO } from "../ai/useAIContext";
import { suggestionsSystemPrompt, parseSuggestions, type Suggestion } from "../ai/suggestions";
import { useTasks, useProfile, useBrainDocs, useSchedule, useRoutine, useOptionalStrands, useOptionalPeople } from "../data/NotesProvider";
import { peopleForDerivation } from "../brain/peopleFacts";
import { readWindow, type WindowClient } from "../brain/window";
import { brainMoments } from "../brain/moments";
import { readChosen } from "../brain/nightly";
import { fadedStrands, daysSince } from "../brain/recall";
import type { Strand } from "../brain/strands/types";
import type { Derived } from "../brain/derive";
import { supabase } from "../auth/supabaseClient";
import { haptics } from "../shared/haptics";
import { showToast } from "../shared/toast";
import { attemptWrite } from "../shared/guard";
import { patternObservation, isPatternDismissed, dismissPattern, appendHabit, type PatternObservation } from "./patterns";
import { planningPatternObservation, readDurationCorrections } from "./planningPatterns";
import { routineBlockCandidate } from "./routinePatterns";
import { addDays } from "../schedule/calendar";
import type { ProtectedBlock } from "../routine/types";
import { emit } from "../events";
import { aiFailure, type AIFailure } from "../ai/failureLine";
import { rankOpen } from "../upnext/upnext";
import { Lightbulb } from "../shared/icons";
import NoticeCard from "./NoticeCard";

// Proactive nudges on Today, made actionable and polite:
// - one AI call per day (cached on device), so no burn on every open
// - yesterday's and today's suggestions are passed back as "do not repeat"
// - a suggestion tied to a real task gets a one-tap "Add to Today"
// - dismissals persist for the day (an assistant that re-nags gets deleted)
type DayCache = { items: Suggestion[]; dismissed: number[]; acted: number[] };
const KEY = (d: string) => "jarvis.suggestions." + d;

function readCache(d: string): DayCache | null {
  try { return JSON.parse(localStorage.getItem(KEY(d)) || "null") as DayCache | null; } catch { return null; }
}
function writeCache(d: string, c: DayCache) {
  try { localStorage.setItem(KEY(d), JSON.stringify(c)); } catch { /* private mode */ }
}

export default function TodaySuggestions({ ai, always = false }: { ai: AIService; always?: boolean }) {
  const gather = useAIContext();
  const tasksSvc = useTasks();
  const profileSvc = useProfile();
  const docs = useBrainDocs();
  const scheduleSvc = useSchedule();
  const routineSvc = useRoutine();
  const today = todayISO();
  const [cache, setCache] = useState<DayCache | null | undefined>(undefined); // undefined = loading
  // Pattern awareness (Phase 2 stretch): one deterministic observation from
  // the check-in history, pinned above the AI rows. Works with AI off too.
  // A pattern row is an observation plus what accepting it DOES. Habit rows
  // write the habits doc (the original pipeline); routine rows (2026-08-09)
  // append a learned block to the routine itself. Same dismiss memory, same
  // one-row rule, different landing place for the tap.
  const [pattern, setPattern] = useState<(PatternObservation & { routineBlock?: ProtectedBlock; moment?: Derived; sub?: string; stale?: Strand }) | null>(null);
  // S4-Q21 (2026-09-04): the nightly pass can hand back up to three moments
  // in one day (see brain/nightly.ts), but `pattern` above only ever holds
  // the single one that won the race against mood/routine/planning
  // candidates. Only What JARVIS Knows (always=true) populates this, so
  // Today's one-row law is untouched: this stays empty there.
  const [moments, setMoments] = useState<Derived[]>([]);
  const strandsSvc = useOptionalStrands();
  // UP-MIND-16 (2026-09-05): Contacts, for the two people derivations. The
  // log carries person ids; the names and the labels live here.
  const peopleSvc = useOptionalPeople();
  // Texts of the tasks already visible in Up Next: a suggestion that echoes
  // one of them is repetition, not value (Dave 2026-07-30), and is hidden.
  const [visibleTaskTexts, setVisibleTaskTexts] = useState<Set<string> | null>(null);
  // S4-Q27 (2026-09-04): "an AI failure looks exactly like a quiet day."
  // The catch below used to just clear the cache; nothing distinguished
  // "JARVIS has nothing today" from "JARVIS is broken." aiFailureLine
  // already exists, tested, and was wired to Email only.
  // TRACE-04 (2026-09-07): the WHOLE failure, not just its headline. The
  // reason travels beside the line so the card can put it somewhere nothing
  // clamps it; see the notice below.
  const [aiError, setAiError] = useState<AIFailure | null>(null);

  const persist = useCallback((c: DayCache) => { setCache(c); writeCache(today, c); }, [today]);

  useEffect(() => {
    let on = true;
    tasksSvc.listTasks().then((items) => {
      if (!on) return;
      setVisibleTaskTexts(new Set(rankOpen(items, today).slice(0, 3).map((t) => t.data.text.toLowerCase())));
    });
    return () => { on = false; };
  }, [tasksSvc, today]);

  useEffect(() => {
    let on = true;
    void (async () => {
      const [prof, events, routine] = await Promise.all([
        profileSvc.get(),
        scheduleSvc.listEvents(),
        routineSvc.get(),
      ]);
      if (!on) return;
      // Priority when several exist: mood (wellbeing outranks everything),
      // then a learned routine block (structure beats a tip), then the
      // planning-duration tip. One row, first non-dismissed candidate wins;
      // the dismiss-memory works on any observation id, unmodified.
      const routineC = routineBlockCandidate(events, routine, Date.now());
      // Being-known moments (Brain Layer 2): derivations on the durable
      // event log, offered last. Mood outranks everything (wellbeing beats a
      // tip), then learned structure, then planning, then these. Best-effort:
      // a failed window read means no moment, never a broken Today.
      let moments: Derived[] = [];
      let faded: Strand[] = [];
      try {
        if (strandsSvc) {
          const [rows, strands, folk] = await Promise.all([
            readWindow(supabase as unknown as WindowClient | null, Date.now()),
            strandsSvc.list(),
            peopleForDerivation(peopleSvc),
          ]);
          // THE NIGHTLY PASS (handoff item 2 + decision x3): the day's set is
          // consolidated once per local day and capped at three, instead of
          // whichever single gate happened to trip while this screen was
          // open. See brain/nightly.ts for why holding it steady matters.
          // UP-MIND-05 (2026-09-05): READS the day's set, which BrainPump
          // decided at the local day rollover. It used to decide it here,
          // which meant a day this screen never rendered was a day the
          // Brain never reviewed at all.
          moments = readChosen(brainMoments(rows, strands, folk), today);
          // FADE (handoff 5.8, decision m1): a fact nobody has confirmed in a
          // season asks whether it still holds. Never a silent deletion and
          // never silent staleness, which is why it is a question here rather
          // than a quiet drop in recall.ts.
          faded = fadedStrands(strands, today);
        }
      } catch { /* silence beats a guess, and definitely beats a crash */ }
      const candidates: (PatternObservation & { routineBlock?: ProtectedBlock; moment?: Derived; sub?: string; stale?: Strand })[] = [
        ...(patternObservation(prof?.checkin, today) ? [patternObservation(prof?.checkin, today)!] : []),
        ...(routineC ? [{ id: routineC.id, text: routineC.text, routineBlock: routineC.block }] : []),
        ...(planningPatternObservation(readDurationCorrections(), Date.now()) ? [planningPatternObservation(readDurationCorrections(), Date.now())!] : []),
        ...moments.map((m) => ({ id: "brain-" + m.derivation, text: m.title, sub: m.sub, moment: m })),
        // Last in the order, behind every proposal: being asked to re-confirm
        // something JARVIS already knows is the least urgent thing on the
        // page, and only one candidate renders anyway.
        ...faded.slice(0, 1).map((s) => ({
          id: "stale-" + s.id,
          text: s.data.text,
          sub: `Still true? Nothing has confirmed this in ${daysSince(s.data.lastConfirmed, today)} days`,
          stale: s,
        })),
      ];
      setPattern(candidates.find((c) => !isPatternDismissed(c.id, today)) ?? null);
      // What JARVIS Knows renders the whole set the pass chose (pick S4-Q21),
      // not just whichever candidate happened to win the row above. Compared
      // by content, not replaced outright: a brand new array on every effect
      // run (this one reruns whenever any service identity changes, e.g. a
      // token refresh) would never be reference-equal to the last one, and
      // React never bails out of the render that follows -- an infinite
      // loop the moment this effect fires more than once with nothing to
      // report.
      if (always) {
        const fresh = moments.filter((m) => !isPatternDismissed("brain-" + m.derivation, today));
        setMoments((cur) =>
          cur.length === fresh.length && cur.every((m, i) => m.derivation === fresh[i]!.derivation)
            ? cur
            : fresh,
        );
      }
    })();
    return () => { on = false; };
  }, [profileSvc, scheduleSvc, routineSvc, strandsSvc, peopleSvc, today, always]);

  useEffect(() => {
    if (!ai.available) return;
    const existing = readCache(today);
    if (existing) { setCache(existing); return; }
    let on = true;
    (async () => {
      try {
        const ctx = await gather();
        // TODAY-F-12 (2026-09-05): a calendar day back, not 86,400,000ms,
        // which on the clocks-forward day is still today.
        const yesterday = readCache(addDays(today, -1));
        const avoid = (yesterday?.items ?? []).map((s) => s.text);
        // B5 (2026-09-04): this fires from a mount effect, not a tap, and
        // carried no flag -- so at "On Request" (which is supposed to mean
        // only calls the user just asked for) it ran anyway. aiGate.ts's
        // aiCallAllowed refuses exactly this shape when told.
        const raw = await ai.complete(
          [{ role: "user", content: "What should I focus on today?" }],
          suggestionsSystemPrompt(ctx, today, avoid),
          { kind: "suggestions", background: true },
        );
        if (!on) return;
        const c: DayCache = { items: parseSuggestions(raw), dismissed: [], acted: [] };
        setCache(c); writeCache(today, c); setAiError(null);
      } catch (e) {
        // Nothing is written to the day's cache here (no writeCache call),
        // so the next open finds no entry and retries instead of a broken
        // day getting remembered forever. aiFailureLine reads the proxy's
        // own upstream error, same message a real "Sign in again" or "Rate
        // limited" deserves rather than silence.
        if (on) { setCache(null); setAiError(aiFailure(e, "Today's suggestions didn't come back")); }
      }
    })();
    return () => { on = false; };
  }, [ai, gather, today]);

  // "JARVIS Noticed" shows at most ONE row, and only when it says something no
  // visible list already says: the deterministic pattern first, else the first
  // AI suggestion that does not echo an Up Next task. Most days: nothing, and
  // nothing renders. Repetition is not value.
  const aiOn = ai.available && cache !== null;
  const items = aiOn ? cache?.items ?? null : null;
  const hidden = new Set([...(cache?.dismissed ?? []), ...(cache?.acted ?? [])]);
  const nonEcho = items
    ? items
        .map((s, i) => ({ s, i }))
        .filter((x) => !hidden.has(x.i))
        .filter((x) => !x.s.task || !visibleTaskTexts?.has(x.s.task.toLowerCase()))
    : [];
  // `always` is What JARVIS Knows (pick 29). On Today this was a whisper you
  // had to tap; on the page about what JARVIS has noticed it IS the content,
  // so it opens as the card.
  //
  // TODAY-F-18 (2026-09-05): STATE OF PLAY, because the whisper is currently
  // unreachable and deleting it would be the wrong call. Its home was Today,
  // and Today no longer mounts this component at all (laws.test.ts:1460 now
  // forbids it and pins StrandsPage.tsx:229 as the only mount), which passes
  // `always`, so `open` starts true and the `!open` branches below never
  // render in the app. They are not dead code in the ordinary sense: they are
  // the Law 3E receipt tier, exercised by a dozen cases in
  // TodaySuggestions.test.tsx, waiting on a surface. Reviving the whisper
  // means giving it a mount, which is a design decision; dropping `always`
  // would open What JARVIS Knows collapsed, which contradicts the ruling in
  // the paragraph above. Left as is, and said out loud.
  const [open, setOpen] = useState(always);
  const aiPick = !pattern && visibleTaskTexts !== null ? nonEcho[0] ?? null : null;
  // The rest of today's moments, beyond whichever one (if any) won the row
  // above -- empty outside What JARVIS Knows, since `moments` is never
  // populated there.
  const extraMoments = moments.filter((m) => m.derivation !== pattern?.moment?.derivation);
  // S4-Q27: a real failure still has to say so, even when everything else
  // this component might show is empty. Silence here used to be identical
  // whether JARVIS had nothing to say or the call behind it broke.
  if (!pattern && !aiPick && extraMoments.length === 0 && !aiError) return null;

  // TODAY-F-22 (2026-09-05): "Add" could succeed with nothing added. The
  // match is an exact, case-insensitive comparison against every open task's
  // text, and a suggestion is the model's own words, so most of the time
  // nothing matched: the row was marked acted, the success haptic fired,
  // suggestion.accepted was logged, and no task had been touched. A failed
  // write did the same thing with the row left on screen. Add now means a
  // task exists with that text due today, whether it was already there or
  // this tap made it, and the row only stands down once the write is real.
  type AddOutcome = "moved" | "created" | null;
  const addToToday = async (idx: number, taskText: string) => {
    let result: AddOutcome = null;
    const ok = await attemptWrite(async () => {
      const all = await tasksSvc.listTasks();
      const hit = all.find((t) => !t.data.done && t.data.text.toLowerCase() === taskText.toLowerCase());
      if (hit) { await tasksSvc.setDue(hit.id, today); result = "moved"; }
      else if (await tasksSvc.createTask(taskText, { due: today })) result = "created";
    });
    const added: AddOutcome = result;
    if (!ok) return;
    // createTask answers null on empty text without throwing, so the id, not
    // the absence of a throw, is what says a task exists.
    if (!added) { showToast({ message: "Couldn't add that" }); return; }
    haptics.success();
    if (added === "created") showToast({ message: "Added to your tasks" });
    // Accepted vs dismissed is how the Brain learns what a "proper
    // suggestion" means for this user (durable log, Session 6.5).
    emit({ type: "suggestion.accepted", props: { kind: "ai" } });
    if (cache) persist({ ...cache, acted: [...cache.acted, idx] });
  };
  const dismiss = (idx: number) => {
    haptics.selection();
    emit({ type: "suggestion.dismissed", props: { kind: "ai" } });
    if (cache) persist({ ...cache, dismissed: [...cache.dismissed, idx] });
  };

  const dismissThis = () => {
    haptics.selection();
    if (pattern) { dismissPattern(pattern.id, today); setPattern(null); emit({ type: "suggestion.dismissed", props: { kind: "pattern" } }); }
    else if (aiPick) dismiss(aiPick.i);
  };

  // A being-known moment becomes a strand with its receipts, wherever it
  // renders: the single row above (when a moment happens to win it) or one
  // of the extra cards below on What JARVIS Knows. Same commit, same three
  // true outcomes, either way.
  // TODAY-F-22 (2026-09-05): guarded. A rejected accept used to take the
  // card off screen and log the acceptance with nothing written behind it.
  const acceptMoment = async (m: Derived): Promise<boolean> => {
    if (!strandsSvc) return false;
    haptics.selection();
    // Three outcomes, three true sentences. This used to be a truthy check
    // on an id, so "you already told me this" and "the Brain is full" both
    // came out as "The Brain is full", which was a lie in the common case.
    let outcome: string | null = null;
    // NO PATTERN (2026-09-07): accepting one answer to a question retires the
    // opposite answer, when he was holding it (StrandsService.accept). A fact
    // leaving his genome is not something to do behind his back, so the tap
    // that caused it says so.
    let replaced = false;
    const ok = await attemptWrite(async () => {
      const r = await strandsSvc.accept(m.strandText, m.category, m.derivation, m.evidence, today);
      outcome = r.outcome;
      replaced = r.outcome === "created" && r.replaced === true;
    });
    const landed: string | null = outcome;
    if (!ok || !landed) return false;
    // UP-MIND-16: the label the moment proposed lands on the person's card
    // in the same tap. Never written without it, and a failed write says so
    // rather than leaving a card claiming a label it does not have.
    if (m.apply?.kind === "person_label" && peopleSvc) {
      const wrote = await attemptWrite(() => peopleSvc.update(m.apply!.personId, { relationship: m.apply!.label }));
      if (!wrote) return false;
    }
    haptics.success();
    showToast({
      message: landed === "created"
        ? (replaced ? "JARVIS will remember that · It replaced what it thought before" : "JARVIS will remember that")
        : landed === "refreshed" ? "JARVIS already knew · Receipts updated"
          : "The Brain is full · Prune it in What JARVIS Knows",
    });
    dismissPattern("brain-" + m.derivation, today);
    setMoments((cur) => cur.filter((x) => x.derivation !== m.derivation));
    return true;
  };
  const dismissMoment = (m: Derived) => {
    haptics.selection();
    emit({ type: "suggestion.dismissed", props: { kind: "brain-moment" } });
    dismissPattern("brain-" + m.derivation, today);
    setMoments((cur) => cur.filter((x) => x.derivation !== m.derivation));
  };

  const acceptPattern = async () => {
    // Explicit tap only, never silent, both paths. A habit row writes the
    // Brain doc every AI feature reads; a routine row (2026-08-09) appends
    // the learned block to the routine, so the planner starts honoring it
    // the next time it runs.
    if (!pattern) return;
    haptics.selection();
    if (pattern.stale) {
      // STILL TRUE (handoff 5.8). Confirming refreshes lastConfirmed, which
      // is what recall.ts reads, so answering the question restores the
      // fact's priority instead of merely silencing the ask.
      //
      // There is deliberately no "Not Anymore" here. This card has one
      // action and a dismiss, and deleting a fact from a passing nudge is
      // the wrong weight for a permanent loss: What JARVIS Knows already
      // holds pause and delete, with the fact in front of you. Dismiss asks
      // again another day, which is the honest middle.
      // TODAY-F-22 (2026-09-05): every branch below writes, and none of them
      // used to catch. A rejected write left the row on screen, said nothing,
      // and the receipt claimed the fact had landed.
      const stale = pattern.stale;
      if (!(await attemptWrite(async () => { await strandsSvc?.confirm(stale, today); }))) return;
      haptics.success();
      showToast({ message: "Still true · JARVIS will keep leaning on it" });
    } else if (pattern.routineBlock) {
      const block = pattern.routineBlock;
      const ok = await attemptWrite(async () => {
        const r = await routineSvc.get();
        await routineSvc.save({ protectedBlocks: [...(r.protectedBlocks ?? []), block] });
      });
      if (!ok) return;
      emit({ type: "suggestion.accepted", props: { kind: "routine" } });
      showToast({ message: "Added to your routine" });
    } else if (pattern.moment && strandsSvc) {
      // The commit lands with weight: this is the hit the Brain exists for.
      if (!(await acceptMoment(pattern.moment))) return;
    } else {
      // Planning observations (per-task timing, the fourth launch
      // derivation) land as strands too, receipts included, so every fact
      // lives in one visible, deletable place. The habits doc remains the
      // fallback when the strand store is absent or refuses (cap reached).
      const timing = pattern.id.match(/^plan-dur-(?:long|short)-(.+)$/);
      let landed = false;
      const text = pattern.text;
      if (timing && strandsSvc) {
        const cat = timing[1]!;
        const evidence = readDurationCorrections()
          .filter((c) => c.category === cat)
          .sort((a, b) => b.ts - a.ts)
          .slice(0, 6)
          // TODAY-F-12 (2026-09-05): the evidence day is the local day the
          // correction was made, not the UTC one.
          .map((c) => ({ day: todayISO(new Date(c.ts)), a: c.deltaMin }));
        let outcome: string | null = null;
        // TODAY-F-22: a write that never landed must not fall through to the
        // habits doc as if the strand store had merely been full, and must
        // not print a receipt either.
        if (!(await attemptWrite(async () => {
          outcome = (await strandsSvc.accept(text, "routine", "task_timing", evidence, today)).outcome;
        }))) return;
        const r: string | null = outcome;
        // A refresh counts as landed. Falling through to the habits doc
        // because the strand already existed is how the same observation
        // ended up written into that document once per accept.
        if (r && r !== "full") {
          landed = true;
          haptics.success();
          showToast({ message: r === "created" ? "JARVIS will remember that" : "JARVIS already knew · Receipts updated" });
        }
      }
      if (!landed) {
        const ok = await attemptWrite(async () => {
          const cur = await docs.get("habits");
          await docs.save("habits", appendHabit(cur, text, today));
        });
        if (!ok) return;
        emit({ type: "suggestion.accepted", props: { kind: "pattern" } });
        showToast({ message: "Saved to your Brain" });
      }
    }
    dismissPattern(pattern.id, today);
    setPattern(null);
  };

  // THE WHISPER (Law 3E receipt tier, cleanup 2026-08-22). An insight is the
  // least urgent thing on the page, and as a full card it sat at the bottom
  // of Dave's screenshot dressed in last week's clothes. It is one quiet
  // line now; tapping it opens the full card (Notice law anatomy, dismiss on
  // the swipe) only when he wants the conversation.
  let primary: ReactNode = null;
  if (pattern) {
    primary = !open ? (
      <div className="pad-x">
        <button className="receipt-line" onClick={() => setOpen(true)}>
          <span className="rl-t">Noticed · {pattern.text}</span>
          <span className="chev" />
        </button>
      </div>
    ) : (
      <NoticeCard
        icon={<Lightbulb className="ic" />}
        tone="cat-fg-yellow"
        title={pattern.text}
        sub={pattern.sub}
        /* THE EVIDENCE IS NOT OPTIONAL ON AN OFFER (2026-09-07). See the note
           on the moment cards below: this card asks him to accept a claim, so
           the claim and the count behind it both have to survive. */
        uniform={false}
        stack
        action={{ label: pattern.stale ? "Still True" : pattern.routineBlock ? "Add to Routine" : "Remember This", onClick: () => void acceptPattern() }}
        onDismiss={dismissThis}
      />
    );
  } else if (aiPick) {
    primary = !open ? (
      <div className="pad-x">
        <button className="receipt-line" onClick={() => setOpen(true)}>
          <span className="rl-t">Noticed · {aiPick.s.text}</span>
          <span className="chev" />
        </button>
      </div>
    ) : (
      <NoticeCard
        icon={<Lightbulb className="ic" />}
        tone="cat-fg-yellow"
        title={aiPick.s.text}
        action={aiPick.s.task ? { label: "Add", onClick: () => void addToToday(aiPick.i, aiPick.s.task!) } : undefined}
        onDismiss={dismissThis}
      />
    );
  } else if (aiError) {
    // S4-Q27: the honest line, same whisper-first shape as a real
    // suggestion. Slate, not yellow: this is a status, not an insight, and
    // NoticeCard's own doctrine reserves the loud tones for a producer that
    // means to alarm.
    primary = !open ? (
      <div className="pad-x">
        <button className="receipt-line" onClick={() => setOpen(true)}>
          <span className="rl-t">Noticed · Couldn't check today's suggestions</span>
          <span className="chev" />
        </button>
      </div>
    ) : (
      /* TRACE-04 (2026-09-07): THE REASON IS NOT A SUB. ai/failureLine.ts
         exists so the upstream's own actionable sentence survives (Dave lost
         two weeks to a wrong error in 2026-09-02), and this card then handed
         it to the one slot that cannot hold it. A uniform card's sub is a
         single clamped nowrap line (.notice-card-uniform .conn-meta), so on
         his phone it read "Today's suggestions didn't come back · Serv...",
         and measured in the built app at 390x844 the shredded-sub latch
         dropped it outright: the reason was not on screen at all. Both are
         the same defect, and both throw away the half he can act on.
         So the reason goes in the foot, which is inside the same card, below
         the uniform row, and is neither clamped nor reachable by the latch.
         The headline keeps the row and the row keeps its 72; the card grows
         only by the reason, only when a call actually failed. The sub is
         gone because it said what the title says. */
      <NoticeCard
        icon={<Lightbulb className="ic" />}
        tone="cat-fg-slate"
        title="Couldn't check today's suggestions"
        foot={aiError.reason ? <div className="pad-x"><div className="notice-why">{aiError.reason}</div></div> : undefined}
        onDismiss={() => setAiError(null)}
      />
    );
  }

  // The rest of today's moments (pick S4-Q21): "Today keeps its one quiet
  // row; What JARVIS Knows renders the whole set the pass chose." `primary`
  // above is that one row, wherever it renders; these are whatever else the
  // nightly pass picked, always full cards (never whispered), since this
  // list only ever exists on the page that already opened everything.
  return (
    <>
      {primary}
      {extraMoments.map((m) => (
        <NoticeCard
          key={m.derivation}
          icon={<Lightbulb className="ic" />}
          tone="cat-fg-yellow"
          title={m.title}
          sub={m.sub}
          /* THE EVIDENCE IS NOT OPTIONAL ON AN OFFER (2026-09-07).
             Measured at 390x844: "Remember This" is 139px of a 326px row, so a
             derived sentence takes both of a uniform card's lines and the
             shredded-sub law then DROPS the sub rather than shredding it. That
             law is right everywhere else and wrong here, because the sub is
             not decoration on this card, it is the receipt: "21 Finishes in
             the fullest 3-hour stretch, out of your last 158" is the whole
             reason to believe the sentence above it. Asking somebody to
             accept a claim about themselves forever, with the evidence
             silently removed, is the one case where a fixed height costs more
             than it buys.
             Opting out is the escape hatch Dave already ruled for mail
             (NoticeCard's own note, 2026-08-25 "mail stays"), for the same
             reason: content this card cannot promise will fit. And the
             uniform ruling was about the TODAY STREAM looking like three
             different components; this component renders only on What JARVIS
             Knows (pinned by laws.test.ts:1551), in a list of at most three
             cards that are all the same kind, so nothing here is being made
             uneven against a neighbour of another sort. */
          uniform={false}
          stack
          action={{ label: "Remember This", onClick: () => void acceptMoment(m) }}
          onDismiss={() => dismissMoment(m)}
        />
      ))}
    </>
  );
}
