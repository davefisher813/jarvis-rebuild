// @vitest-environment jsdom
import { describe, it, expect } from "vitest";
import { renderHook, waitFor } from "@testing-library/react";
import { NotesProvider, useDecisions, useStrands, useProfile, useNotes, usePeople } from "../data/NotesProvider";
import { useAIContext, useOptionalAIContext, todayISO } from "./useAIContext";

// Brain Personalization Phase 3. Both hooks funnel through one gatherFrom, so
// what is worth testing is the difference between them: what happens when the
// provider is not there.

describe("useOptionalAIContext", () => {
  it("resolves null instead of throwing when NotesProvider is absent", async () => {
    const { result } = renderHook(() => useOptionalAIContext());
    await expect(result.current()).resolves.toBeNull();
  });

  it("assembles the real context when the provider is there", async () => {
    const { result } = renderHook(() => useOptionalAIContext(), {
      wrapper: ({ children }) => <NotesProvider userId="u1">{children}</NotesProvider>,
    });
    await waitFor(async () => {
      const ctx = await result.current();
      expect(ctx).not.toBeNull();
      expect(typeof ctx!.name).toBe("string");
    });
  });
});

describe("useAIContext", () => {
  // The required version stays required: features that genuinely cannot work
  // without the user's data should fail loudly, not silently reason from a
  // blank profile.
  it("throws without NotesProvider, unchanged", () => {
    expect(() => renderHook(() => useAIContext())).toThrow();
  });
});

// B5 (2026-09-04): ruledOut is the Decision Record's whole stop-relitigating
// block -- captured, edited, and shown as its own "Ruled Out" section -- and
// it never reached this read-back, so JARVIS could propose back the exact
// option a record closed.
describe("useOptionalAIContext carries ruled-out options (B5)", () => {
  it("folds ruledOut into the decision's context line", async () => {
    function Seed({ onDone }: { onDone: () => void }) {
      const decisions = useDecisions();
      void decisions.create({
        decision: "Ship on Supabase",
        why: "RLS beats hand-rolled auth checks",
        ruledOut: ["Firebase", "raw Postgres"],
      }).then(onDone);
      return null;
    }
    let seeded = false;
    const { result } = renderHook(() => useOptionalAIContext(), {
      wrapper: ({ children }) => (
        <NotesProvider userId="u-ruledout">
          <Seed onDone={() => { seeded = true; }} />
          {children}
        </NotesProvider>
      ),
    });
    await waitFor(() => expect(seeded).toBe(true));
    await waitFor(async () => {
      const ctx = await result.current();
      const line = ctx?.decisions?.find((d) => d.startsWith("Ship on Supabase"));
      expect(line).toBe("Ship on Supabase (because RLS beats hand-rolled auth checks; ruled out: Firebase, raw Postgres)");
    });
  });
});

// S4-Q25 (2026-09-04): "facts about your writing never reach the drafting
// prompt." The strand's bucket has to survive from the store, through this
// gatherer, to be worth anything -- this proves it does, and that only the
// Writing bucket ends up in the scoped field.
describe("useOptionalAIContext scopes writingFacts to the Writing bucket (S4-Q25)", () => {
  it("carries only the Writing-bucket strand, leaving the general strands list unscoped", async () => {
    function Seed({ onDone }: { onDone: () => void }) {
      const strands = useStrands();
      void Promise.all([
        strands.add("Never opens with Hi there", "writing", "2026-09-04"),
        strands.add("Never schedule calls before 10", "work_style", "2026-09-04"),
      ]).then(onDone);
      return null;
    }
    let seeded = false;
    const { result } = renderHook(() => useOptionalAIContext(), {
      wrapper: ({ children }) => (
        <NotesProvider userId="u-writing-facts">
          <Seed onDone={() => { seeded = true; }} />
          {children}
        </NotesProvider>
      ),
    });
    await waitFor(() => expect(seeded).toBe(true));
    await waitFor(async () => {
      const ctx = await result.current();
      expect(ctx?.writingFacts).toEqual(["Never opens with Hi there"]);
      expect(ctx?.strands).toEqual(expect.arrayContaining(["Never opens with Hi there", "Never schedule calls before 10"]));
    });
  });
});

// S5-Q33 (2026-09-04): the Money tab's payHalfOn gate and this file's own
// cashFlow gate used to be two separate "=== personal" checks, kept in sync
// only by a comment. Student is meant to see the same payday math the
// screen now shows; Business must not, so the AI never quotes a paycheck
// figure the screen itself refuses to fabricate.
describe("useOptionalAIContext: cashFlow follows the same gate as the Money tab (S5-Q33)", () => {
  function SeedProfile({ template, onDone }: { template: "personal" | "business" | "student"; onDone: () => void }) {
    const profile = useProfile();
    void profile.save({ template, payday: { amount: 500, next: todayISO(), freq: "biweekly" } }).then(onDone);
    return null;
  }

  it("Student gets a real cashFlow, not the old Personal-only cutoff", async () => {
    let seeded = false;
    const { result } = renderHook(() => useOptionalAIContext(), {
      wrapper: ({ children }) => (
        <NotesProvider userId="ai-student-pay">
          <SeedProfile template="student" onDone={() => { seeded = true; }} />
          {children}
        </NotesProvider>
      ),
    });
    await waitFor(() => expect(seeded).toBe(true));
    await waitFor(async () => {
      const ctx = await result.current();
      expect(ctx?.cashLine).toMatch(/^Next paycheck \$500/);
    });
  });

  it("Business still gets no cashLine: irregular revenue is not a paycheck", async () => {
    let seeded = false;
    const { result } = renderHook(() => useOptionalAIContext(), {
      wrapper: ({ children }) => (
        <NotesProvider userId="ai-business-pay">
          <SeedProfile template="business" onDone={() => { seeded = true; }} />
          {children}
        </NotesProvider>
      ),
    });
    await waitFor(() => expect(seeded).toBe(true));
    await waitFor(async () => {
      const ctx = await result.current();
      expect(ctx?.cashLine).toBeFalsy();
    });
  });
});

// UP-MIND-23 class (2026-09-07): a scoped prompt has said "Already decided:
// <x>" for a linked decision since B5; the identical line for a linked NOTE
// never appeared, because this hook fed relatedLines a hardcoded [] instead
// of ever calling NotesService.list(). This proves the wire end to end: a
// note connected to a person now surfaces as "Note: <title>" the moment the
// prompt is scoped to that person, the same way the decision above does.
describe("useOptionalAIContext carries a linked note (UP-MIND-23 class)", () => {
  it('folds a note connected to the person into "Note: <title>"', async () => {
    function Seed({ onDone }: { onDone: (personId: string) => void }) {
      const notes = useNotes();
      const people = usePeople();
      void (async () => {
        const personId = (await people.create({ name: "Nadia Brandt", group: "contacts" }))!;
        const noteId = (await notes.createNote("Venue options", "work"))!;
        await notes.addConnection(noteId, "person", "Nadia Brandt", personId);
        onDone(personId);
      })();
      return null;
    }
    let personId = "";
    const { result } = renderHook(() => useOptionalAIContext(), {
      wrapper: ({ children }) => (
        <NotesProvider userId="u-linked-note">
          <Seed onDone={(id) => { personId = id; }} />
          {children}
        </NotesProvider>
      ),
    });
    await waitFor(() => expect(personId).not.toBe(""));
    await waitFor(async () => {
      const ctx = await result.current({ personId, personName: "Nadia Brandt" });
      expect(ctx?.related).toContain("Note: Venue options");
    });
  });
});

// B2-4 (2026-09-04): "the Notifications screen rolls over at 8 PM." This
// todayISO used to read UTC. Four other callers (Chat, Today's suggestions,
// Quick Capture, the Brain's strands page) share it, and Notifications used
// it as its only notion of today with nothing local to disagree with.
describe("todayISO", () => {
  it("reads the local calendar day, not UTC's", () => {
    const prevTz = process.env.TZ;
    process.env.TZ = "America/New_York";
    try {
      // 11 PM Eastern on the 3rd is already the 4th in UTC.
      const d = new Date("2026-09-03T23:00:00-04:00");
      expect(todayISO(d)).toBe("2026-09-03");
    } finally {
      process.env.TZ = prevTz;
    }
  });
});
