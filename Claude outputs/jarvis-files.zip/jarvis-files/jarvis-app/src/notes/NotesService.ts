import type { Store, ItemData } from "@core";
import type { EventInput } from "../events";
import { madeBy, type Source } from "../shared/provenance";
import { shortDateFromMs } from "../shared/dateFormat";
import {
  ENTITY_NOTE,
  ENTITY_TASK,
  TEMPLATES,
  type Block,
  type ChecklistItem,
  type Connection,
  type NoteData,
  type TaskData,
  type TemplateKey,
} from "./types";

function genId(prefix: string): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return prefix + "_" + crypto.randomUUID();
  }
  return prefix + "_" + Math.random().toString(36).slice(2);
}

// The real Notes feature, backed by the verified engine Store. One instance per
// signed-in user (ownerId fixed). Block and connection edits are read-modify-
// write on the note's data: read the note, change the array, write the field
// back. The engine's last-write-wins handles field-level conflicts. onEvent
// feeds the gaming event bus (no-op in tests).
export class NotesService {
  constructor(
    private store: Store,
    private ownerId: string,
    private onEvent: (e: EventInput) => void = () => {},
  ) {}

  private async getNote(id: string): Promise<NoteData | null> {
    const item = await this.store.read(this.ownerId, id);
    if (!item || item.entityType !== ENTITY_NOTE) return null;
    return item.data as unknown as NoteData;
  }

  async note(id: string): Promise<NoteData | null> {
    return this.getNote(id);
  }

  // PICK 27 (2026-08-24): a note may be BORN linked. A note written while
  // inside a project belongs to that project, and asking the user to go find
  // the link picker afterwards is how the link never gets made. The reverse
  // lookup (notesLinkedTo) has existed since Session 6 and had nothing
  // feeding it except manual linking.
  // UP-CORE-05 (2026-09-05): `source` is the provenance stamp for a note the
  // app made on its own (a capture, a paste, a file). Absent for the ones a
  // person typed, which is what keeps the line meaningful when it appears.
  async createNote(title: string, category: string, connections: Connection[] = [], source?: Source): Promise<string | null> {
    if (!title || !String(title).trim()) return null;
    const data: NoteData = { title, category, blocks: [], connections, ...(source ? { source } : {}) };
    const id = await this.store.create(this.ownerId, ENTITY_NOTE, data as unknown as ItemData);
    this.onEvent({ type: "entity.created", entityType: ENTITY_NOTE, entityId: id });
    return id;
  }

  async editTitle(id: string, title: string): Promise<void> {
    await this.store.update(this.ownerId, id, { title });
    this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: id });
  }

  // A note's category is a real connection, not a label chosen once at
  // creation. Changing it is how a note moves between areas of your life.
  async setCategory(id: string, category: string): Promise<void> {
    if (!category) return;
    await this.store.update(this.ownerId, id, { category } as unknown as ItemData);
    this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: id });
  }

  /** File a note under an area, or "" to unfile it (the swipe's File, 2026-09-02). */
  async fileUnder(id: string, category: string): Promise<void> {
    await this.store.update(this.ownerId, id, { category } as unknown as ItemData);
    this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: id });
  }

  /**
   * THE GREAT UNFILING (2026-08-30). A one-time cleanup for the notes written
   * before creation was fixed to be born unfiled (Law 11, finding 4).
   *
   * The old createNote silently filed every note into catList[0] -- whatever
   * category happened to sort first, which for Dave is Family -- so a library
   * he never filed by hand rendered as one uniform colour and the colour said
   * nothing. Fixing creation only helps notes written from now on; the
   * existing library still wears a category nobody chose. This clears it, so
   * those notes fall back to the unfiled yellow and filing becomes a real
   * choice again.
   *
   * Idempotent by construction: it only touches notes that still HAVE a
   * category, so a second run is a no-op and the notes he has since refiled by
   * hand are the ones it must not touch. Returns how many it cleared, which is
   * what makes "it already ran" observable in a test rather than assumed.
   *
   * setCategory refuses an empty string on purpose (an empty category is not a
   * category), so this writes through the store directly rather than lying to
   * that guard.
   */
  async unfileAllNotes(): Promise<number> {
    const items = await this.store.listForUser(this.ownerId, ENTITY_NOTE);
    let cleared = 0;
    for (const it of items) {
      const data = it.data as unknown as NoteData;
      if (!data.category) continue;
      await this.store.update(this.ownerId, it.id, { category: "" } as unknown as ItemData);
      this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: it.id });
      cleared++;
    }
    return cleared;
  }

  async addBlock(id: string, block: Omit<Block, "id">): Promise<string | null> {
    const note = await this.getNote(id);
    if (!note) return null;
    const b: Block = { id: genId("b"), ...block };
    const blocks = [...note.blocks, b];
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: id });
    return b.id;
  }

  // Canvas typing flow: pressing Enter continues the document, so new blocks
  // land right after the one being written, not at the end of the note.
  async insertBlockAfter(id: string, afterBlockId: string, block: Omit<Block, "id">): Promise<string | null> {
    const note = await this.getNote(id);
    if (!note) return null;
    const idx = note.blocks.findIndex((b) => b.id === afterBlockId);
    if (idx < 0) return this.addBlock(id, block);
    const b: Block = { id: genId("b"), ...block };
    const blocks = [...note.blocks.slice(0, idx + 1), b, ...note.blocks.slice(idx + 1)];
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: id });
    return b.id;
  }

  async addChecklist(id: string, items: string[]): Promise<string | null> {
    const checklistItems: ChecklistItem[] = items.map((t) => ({ text: t, done: false }));
    return this.addBlock(id, { type: "checklist", items: checklistItems });
  }

  async editBlock(id: string, blockId: string, patch: Partial<Block>): Promise<boolean> {
    const note = await this.getNote(id);
    if (!note) return false;
    const idx = note.blocks.findIndex((b) => b.id === blockId);
    if (idx < 0) return false;
    const blocks = note.blocks.slice();
    blocks[idx] = { ...blocks[idx]!, ...patch, id: blockId };
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    return true;
  }

  // Undo support (2026-08-19): a note's blocks are one array, so undo is a
  // wholesale restore of a prior snapshot. The flow owns the history stack.
  async setBlocks(id: string, blocks: Block[]): Promise<boolean> {
    const note = await this.getNote(id);
    if (!note) return false;
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    this.onEvent({ type: "entity.updated", entityType: ENTITY_NOTE, entityId: id });
    return true;
  }

  async moveBlock(id: string, from: number, to: number): Promise<boolean> {
    const note = await this.getNote(id);
    if (!note) return false;
    const blocks = note.blocks.slice();
    if (from < 0 || from >= blocks.length || to < 0 || to >= blocks.length) return false;
    const [moved] = blocks.splice(from, 1);
    blocks.splice(to, 0, moved!);
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    return true;
  }

  async deleteBlock(id: string, blockId: string): Promise<boolean> {
    const note = await this.getNote(id);
    if (!note) return false;
    const idx = note.blocks.findIndex((b) => b.id === blockId);
    if (idx < 0) return false;
    const blocks = note.blocks.slice();
    blocks.splice(idx, 1);
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    return true;
  }

  async applyTemplate(id: string, key: TemplateKey): Promise<boolean> {
    const note = await this.getNote(id);
    if (!note) return false;
    const template = TEMPLATES[key];
    if (!template) return false;
    const blocks: Block[] = template.map((b) => ({ id: genId("b"), ...JSON.parse(JSON.stringify(b)) }));
    // The dated pieces a static template can't carry: a meeting opens with
    // its date and attendee line; a journal opens with today's first entry.
    const today = shortDateFromMs(Date.now());
    if (key === "meeting") blocks.unshift({ id: genId("b"), type: "meta", text: today + " · Attendees" });
    if (key === "journal") blocks.push({ id: genId("b"), type: "heading", text: today }, { id: genId("b"), type: "text", text: "" });
    await this.store.update(this.ownerId, id, { blocks } as unknown as ItemData);
    return true;
  }

  // A NOTE FOR THIS MEETING, ALREADY LINKED (UP-CORE-08, 2026-09-05).
  //
  // Walking into the 2 PM with a page titled and linked is the whole ask.
  // Everything this needs already existed and had never been put together:
  // the meeting template (Agenda, Decisions, Action Items), createNote, and
  // addConnection(kind "event"), whose reverse lookup notesLinkedTo is read
  // for tasks, projects and people and was never once read for an event.
  //
  // The connection LABEL carries the occurrence date, not just the title, so
  // a weekly stand-up has one note per week rather than every occurrence
  // pointing at the first one's page. The connection's targetId is still the
  // series id, because that is what the row can look up.
  //
  // The provenance stamp is "event", so the note's own head line says "From
  // your calendar" and opens the meeting it belongs to.
  async createForEvent(event: { id: string; title: string; date: string; category?: string }): Promise<string | null> {
    const title = event.title.trim();
    if (!title || !event.date) return null;
    const id = await this.createNote(
      `${title} · ${shortDateFromMs(new Date(event.date + "T12:00:00").getTime())}`,
      event.category ?? "",
      [],
      madeBy("event", event.id),
    );
    if (!id) return null;
    await this.applyTemplate(id, "meeting");
    await this.addConnection(id, "event", `${title} · ${event.date}`, event.id);
    return id;
  }

  // Which of these events have a note already, in ONE pass over the notes
  // list. The row needs a yes or no per event and a read per row would be a
  // list scan per row.
  async eventsWithNotes(eventIds: string[]): Promise<Set<string>> {
    const want = new Set(eventIds.filter(Boolean));
    if (want.size === 0) return new Set();
    const items = await this.store.listForUser(this.ownerId, ENTITY_NOTE);
    const out = new Set<string>();
    for (const it of items) {
      const d = it.data as unknown as NoteData;
      for (const c of d.connections ?? []) {
        if (c.kind === "event" && c.targetId && want.has(c.targetId)) out.add(c.targetId);
      }
    }
    return out;
  }

  async addConnection(
    id: string,
    kind: string,
    label: string,
    targetId?: string,
  ): Promise<string | null> {
    const note = await this.getNote(id);
    if (!note) return null;
    const conn: Connection = { id: genId("c"), kind, label };
    if (targetId) conn.targetId = targetId;
    const connections = [...note.connections, conn];
    await this.store.update(this.ownerId, id, { connections } as unknown as ItemData);
    return conn.id;
  }

  async removeConnection(id: string, connId: string): Promise<boolean> {
    const note = await this.getNote(id);
    if (!note) return false;
    const idx = note.connections.findIndex((c) => c.id === connId);
    if (idx < 0) return false;
    const connections = note.connections.slice();
    connections.splice(idx, 1);
    await this.store.update(this.ownerId, id, { connections } as unknown as ItemData);
    return true;
  }

  // Each checklist item becomes a task item, linked one-way to the note and
  // inheriting the note's category. Tasks are independent items, so they
  // survive note deletion.
  //
  // Idempotent: items that already have a taskId are skipped (running it twice
  // no longer duplicates every task), blanks are skipped, and each created
  // task's id is stored back on the item so the two stay in sync.
  //
  // B4 (2026-09-04): the Create Tasks screen previews exactly ONE checklist
  // (the note's first) filtered to undone items, and its copy promises
  // "Completed ones skipped." This used to walk every checklist block and
  // skip only blanks and already-linked items, so a done item, or a second
  // checklist the preview never showed, silently produced tasks the button's
  // own count didn't account for. Now it operates over the same first
  // checklist, the same way, so what gets created is what was shown.
  //
  // S6-Q38 (2026-09-05): "a task made from a checklist is not connected to
  // its note." fromNote made the link one-way -- the task's provenance named
  // the note, but the note's own Connections list, and the reverse lookup
  // (notesLinkedTo) that feeds the task sheet's Linked Notes section, both
  // read only note.connections, which this never wrote to. Each created task
  // now gets a real connection back on the note, so both of the app's
  // existing "find the other end" screens light up rather than staying blind
  // to a link that in fact exists.
  async tasksFromChecklist(id: string): Promise<string[]> {
    const note = await this.getNote(id);
    if (!note) return [];
    const block = note.blocks.find((b) => b.type === "checklist" && !!b.items);
    if (!block || block.type !== "checklist" || !block.items) return [];
    const made: string[] = [];
    const items = this.normalizeItems(block.items);
    let changed = false;
    for (let i = 0; i < items.length; i++) {
      const it = items[i]!;
      if (!it.text.trim() || it.taskId || it.done) continue;
      const data: TaskData = { text: it.text, fromNote: id, category: note.category, done: it.done, source: madeBy("note", id) };
      const tid = await this.store.create(this.ownerId, ENTITY_TASK, data as unknown as ItemData);
      await this.addConnection(id, "task", it.text, tid);
      items[i] = { ...it, taskId: tid };
      changed = true;
      made.push(tid);
    }
    if (changed) await this.editBlock(id, block.id, { items });
    return made;
  }

  // ONE LINE, ONE TASK (UP-CORE-16, 2026-09-05).
  //
  // Meeting notes produce action items one at a time, and the only way to
  // get one out was the bulk Create Tasks screen three taps away, which
  // makes tasks out of the WHOLE list. So the line that is actually an
  // action stayed in the note. This is tasksFromChecklist's body for a
  // single item, deliberately sharing every one of its rules: the same
  // fromNote and "From a note" provenance, the same connection written back
  // on the note so both directions of the link light up (S6-Q38), the same
  // taskId stored on the item so the two stay in sync, and the same refusal
  // to promote a blank line or one that is already linked.
  //
  // Returns the new task's id, or null when there was nothing to promote,
  // so the caller can offer an Undo only when something happened.
  async taskFromChecklistItem(noteId: string, blockId: string, index: number): Promise<string | null> {
    const note = await this.getNote(noteId);
    if (!note) return null;
    const block = note.blocks.find((b) => b.id === blockId);
    if (!block || block.type !== "checklist" || !block.items) return null;
    const items = this.normalizeItems(block.items);
    const it = items[index];
    if (!it || !it.text.trim() || it.taskId) return null;
    const data: TaskData = { text: it.text, fromNote: noteId, category: note.category, done: it.done, source: madeBy("note", noteId) };
    const tid = await this.store.create(this.ownerId, ENTITY_TASK, data as unknown as ItemData);
    await this.addConnection(noteId, "task", it.text, tid);
    items[index] = { ...it, taskId: tid };
    await this.editBlock(noteId, blockId, { items });
    return tid;
  }

  // The other half of the Undo: the task itself is deleted by the caller
  // (TasksService owns tasks), and this takes the line back to unlinked and
  // drops the connection the promotion added, so the note is exactly as it
  // was rather than carrying a chip pointing at a deleted task.
  async unlinkChecklistItem(noteId: string, blockId: string, index: number): Promise<boolean> {
    const note = await this.getNote(noteId);
    if (!note) return false;
    const block = note.blocks.find((b) => b.id === blockId);
    if (!block || block.type !== "checklist" || !block.items) return false;
    const items = this.normalizeItems(block.items);
    const it = items[index];
    if (!it?.taskId) return false;
    const conn = (note.connections ?? []).find((c) => c.kind === "task" && c.targetId === it.taskId);
    if (conn) await this.removeConnection(noteId, conn.id);
    const { taskId: _gone, ...rest } = it;
    void _gone;
    items[index] = rest;
    await this.editBlock(noteId, blockId, { items });
    return true;
  }

  // Pull linked-task completion states back into the note's checklist, so a
  // task checked off in Tasks shows checked here too. Writes only on drift.
  async reconcileChecklistTasks(id: string): Promise<void> {
    const note = await this.getNote(id);
    if (!note) return;
    const tasks = await this.listTasks();
    const doneById = new Map(tasks.map((t) => [t.id, !!(t.data as unknown as TaskData).done]));
    for (const block of note.blocks) {
      if (block.type !== "checklist" || !block.items) continue;
      const items = this.normalizeItems(block.items);
      let changed = false;
      for (let i = 0; i < items.length; i++) {
        const it = items[i]!;
        if (!it.taskId || !doneById.has(it.taskId)) continue;
        const taskDone = doneById.get(it.taskId)!;
        if (it.done !== taskDone) { items[i] = { ...it, done: taskDone }; changed = true; }
      }
      if (changed) await this.editBlock(id, block.id, { items });
    }
  }

  private normalizeItems(items: Block["items"]): ChecklistItem[] {
    return (items ?? []).map((it) => (typeof it === "string" ? { text: it, done: false } : it));
  }

  async toggleChecklistItem(noteId: string, blockId: string, index: number): Promise<boolean> {
    const note = await this.getNote(noteId);
    if (!note) return false;
    const block = note.blocks.find((b) => b.id === blockId);
    if (!block || block.type !== "checklist") return false;
    const items = this.normalizeItems(block.items);
    if (index < 0 || index >= items.length) return false;
    const next = !items[index]!.done;
    items[index] = { ...items[index]!, done: next };
    const ok = await this.editBlock(noteId, blockId, { items });
    // Keep the linked task (if this item was promoted) in the same state.
    const taskId = items[index]!.taskId;
    if (ok && taskId) {
      try { await this.store.update(this.ownerId, taskId, { done: next } as unknown as ItemData); }
      catch { /* the task may have been deleted; the note toggle still stands */ }
    }
    return ok;
  }

  async setChecklistItemText(noteId: string, blockId: string, index: number, text: string): Promise<boolean> {
    const note = await this.getNote(noteId);
    if (!note) return false;
    const block = note.blocks.find((b) => b.id === blockId);
    if (!block || block.type !== "checklist") return false;
    const items = this.normalizeItems(block.items);
    if (index < 0 || index >= items.length) return false;
    items[index] = { ...items[index]!, text };
    return this.editBlock(noteId, blockId, { items });
  }

  // Append a blank checklist item (the editor focuses it for typing). Returns
  // the new item's index so the caller can focus it.
  async addChecklistItem(noteId: string, blockId: string): Promise<number | null> {
    const note = await this.getNote(noteId);
    if (!note) return null;
    const block = note.blocks.find((b) => b.id === blockId);
    if (!block || block.type !== "checklist") return null;
    const items = this.normalizeItems(block.items);
    items.push({ text: "", done: false });
    const ok = await this.editBlock(noteId, blockId, { items });
    return ok ? items.length - 1 : null;
  }

  // Remove a checklist item (used when an item is left blank on blur, so no
  // orphaned empty checkboxes remain).
  async deleteChecklistItem(noteId: string, blockId: string, index: number): Promise<boolean> {
    const note = await this.getNote(noteId);
    if (!note) return false;
    const block = note.blocks.find((b) => b.id === blockId);
    if (!block || block.type !== "checklist") return false;
    const items = this.normalizeItems(block.items);
    if (index < 0 || index >= items.length) return false;
    items.splice(index, 1);
    return this.editBlock(noteId, blockId, { items });
  }

  async deleteNote(id: string): Promise<void> {
    await this.store.delete(this.ownerId, id);
    this.onEvent({ type: "entity.deleted", entityType: ENTITY_NOTE, entityId: id });
  }

  // Recreate a just-deleted note whole: blocks, connections, everything. This
  // exists so note deletion can use the app's one convention for destructive
  // actions, delete-then-Undo-toast (tasks set it), instead of the
  // window.confirm dialog it had (audit 2026-08-07).
  //
  // HMN-F-15 (2026-09-05): under its OLD id when the caller has it. The note
  // used to come back under a new one, so the tasks made from its checklist
  // (fromNote) and the Where You Were spot on Today still pointed at an id
  // that opened nothing. The row is gone by the time Undo is tappable, so
  // the id is free to take again.
  async restoreNote(data: NoteData, id?: string): Promise<string | null> {
    const newId = await this.store.create(this.ownerId, ENTITY_NOTE, data as unknown as ItemData, id);
    this.onEvent({ type: "entity.created", entityType: ENTITY_NOTE, entityId: newId });
    return newId;
  }

  async listNotes() {
    return this.store.listForUser(this.ownerId, ENTITY_NOTE);
  }

  /**
   * The demo seed's one door to "edited when". The library's second line
   * reads each note's server time as its last edit; the in-memory store
   * hands out a bare counter, so the seed stamps its notes with real epoch
   * millis (oldest first: the store's clock only moves forward). Production
   * never calls this, and its server would ignore the stamp anyway: the
   * live adapter owns time (updated_at) and drops the argument.
   */
  async stampEdited(id: string, epochMs: number): Promise<void> {
    await this.store.update(this.ownerId, id, {}, epochMs);
  }

  // Reverse lookup: every note whose connections point at the given entity id.
  // Returns light summaries so callers (project/task/person screens) can show a
  // "Linked Notes" section without loading full note bodies.
  async notesLinkedTo(targetId: string): Promise<{ id: string; title: string; category: string }[]> {
    if (!targetId) return [];
    const items = await this.store.listForUser(this.ownerId, ENTITY_NOTE);
    const out: { id: string; title: string; category: string }[] = [];
    for (const it of items) {
      // connections membership is a JSONB predicate the DB query does not
      // express; that filtering stays in memory by design.
      const d = it.data as unknown as NoteData;
      if (Array.isArray(d.connections) && d.connections.some((c) => c.targetId === targetId)) {
        out.push({ id: it.id, title: d.title || "Untitled", category: d.category || "" });
      }
    }
    return out;
  }

  async listTasks() {
    return this.store.listForUser(this.ownerId, ENTITY_TASK);
  }

  // UP-MIND-23 class (2026-09-07): brain/related.ts has taken a `notes` list
  // shaped like this since the day it shipped (title + connections, the same
  // shape decisions.list() already returns for its own kind), so a scoped AI
  // context could say "Note: <title>" the same way it says "Already decided:
  // <x>". Nothing ever called it: useAIContext.ts passed a hardcoded []
  // instead, so a note connected to the person or project being written
  // about never once reached the prompt. Connection.kind/targetId are
  // renamed here to relatedLines' type/id - the two modules picked different
  // words for the same idea before either could see the other's shape.
  async list(): Promise<{ title: string; connections?: { type: string; id: string }[] }[]> {
    const items = await this.store.listForUser(this.ownerId, ENTITY_NOTE);
    return items.map((it) => {
      const d = it.data as unknown as NoteData;
      return {
        title: d.title || "Untitled",
        connections: (d.connections ?? [])
          .filter((c) => !!c.targetId)
          .map((c) => ({ type: c.kind, id: c.targetId! })),
      };
    });
  }

  // offline controls pass through to the engine store
  goOffline() {
    this.store.goOffline();
  }
  reconnect() {
    return this.store.reconnect();
  }
  queueLen() {
    return this.store.queueLen();
  }
}
